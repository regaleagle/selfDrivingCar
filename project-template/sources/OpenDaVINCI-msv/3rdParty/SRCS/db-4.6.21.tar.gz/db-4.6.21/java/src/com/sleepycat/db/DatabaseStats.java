/*-
 * See the file LICENSE for redistribution information.
 *
 * Copyright (c) 1997,2007 Oracle.  All rights reserved.
 *
 * $Id: DatabaseStats.java,v 12.7 2007/06/28 14:23:36 mjc Exp $
 */
package com.sleepycat.db;

public abstract class DatabaseStats {
    // no public constructor
    /* package */ DatabaseStats() {}
}
